
#Test system
You need Python 3.4 package for ArcGis pro to open 64bit version.

So install it from your installation media
 - Open test.py
 - run
 
