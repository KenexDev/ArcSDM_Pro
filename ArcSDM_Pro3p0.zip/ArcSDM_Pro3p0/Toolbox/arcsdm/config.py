# -*- coding: utf-8 -*-

USE_PTVS_DEBUGGER = False
RELOAD_MODULES = True

VERBOSE = False
