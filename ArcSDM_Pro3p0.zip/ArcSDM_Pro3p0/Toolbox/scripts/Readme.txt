This directory contains copies of original not-anymore-necessary scripts for developer reference only. 

